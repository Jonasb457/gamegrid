const express = require('express');
const tournamentController = require('../controllers/tournamentController');

const router = express.Router();

router.post('/', tournamentController.createTournament);
router.get('/', tournamentController.getAllTournaments);

module.exports = router;
