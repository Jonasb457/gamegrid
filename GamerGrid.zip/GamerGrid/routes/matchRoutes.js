const express = require('express');
const matchController = require('../controllers/matchController');

const router = express.Router();

router.post('/', matchController.createMatch);
router.get('/tournament/:tournamentId', matchController.getMatchesByTournament);

module.exports = router;
