import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import LoginPage from './components/LoginPage'; // Check this import
import MainScreen from './components/Mainscreen'; // Check this import
import RegistrationForm from './components/RegistrationForm'; // Check this import
import TournamentPage from './components/TournamentPage';
function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    const handleLogin = async (email, password) => {
        try{
            
            console.log('Attempting login with:', email, password); 


            if (email === "test@example.com" && password === "password123") {
                setIsLoggedIn(true);
                alert("Test user logged in successfully!");
                return;
            }
            const response = await fetch("http://localhost:3000/api/users/login", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email, password }),
                });
                
                console.log('Response status:', response.status);
        
                if (!response.ok) {
                    const errorData = await response.json();
                    alert(errorData.message || "Failed to log in.");
                    console.log('Error response:', errorData);
                    return;
                }
        
                const data = await response.json();
                setIsLoggedIn(true);
                alert("Login successful!"); 
                console.log(data);

                } catch (error) {
                console.error("Error during login:", error);
                alert("An error occurred. Please try again later.");
            }
        };

    return (
        <Router>
            <Routes>
                <Route path="/" element={isLoggedIn ? <MainScreen /> : <LoginPage onLogin={handleLogin} />} />
                <Route path="/register/:tournamentId" element={<RegistrationForm />} />
                <Route path="/tournament/:tournamentId" element={<TournamentPage />} />
            </Routes>
        </Router>
    );
}

export default App;







