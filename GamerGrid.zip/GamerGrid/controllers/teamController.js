const Team = require('../models/teamModel');

// Create a team
exports.createTeam = async (req, res) => {
    try {
        const team = await Team.create(req.body);
        res.status(201).json(team);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get all teams in a tournament
exports.getTeamsByTournament = async (req, res) => {
    try {
        const teams = await Team.find({ tournamentId: req.params.tournamentId });
        res.status(200).json(teams);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
