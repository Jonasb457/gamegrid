const Match = require('../models/matchModel');

// Create a match
exports.createMatch = async (req, res) => {
    try {
        const match = await Match.create(req.body);
        res.status(201).json(match);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
};

// Get matches by tournament
exports.getMatchesByTournament = async (req, res) => {
    try {
        const matches = await Match.find({ tournamentId: req.params.tournamentId }).populate(['team1Id', 'team2Id']);
        res.status(200).json(matches);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
